Sucos Fontextractor von Suco-X erstellt im Jahr 2007
- E-mail:         sucobb@gmx.net 
- Blitzforum:    http://www.blitzforum.de
- bmpfont Lib: http://www.chaos-interactive.de/file.php?id=41
- BlitzMax:      http://www.blitzmax.com 

Wof�r der Fontextractor ist:
Der Suco Fontextractor ist ein kleines Tool, mit dem der Benutzer beliebige Zeichenketten
aus einem Freetype Font in eine Bilddatei speichern kann. Diese Bilddatei kann danach 
mit einem beliebigen Grafikprogramm wie PhotoShop, PaintShop oder Gimp bearbeitet 
werden und danach mit Hilfe der bmpfont Lib von D-Bug wieder geladen werden. Diese Lib ist 
unter dem Link ( http://www.chaos-interactive.de/file.php?id=41 ) erh�ltlich und weitere 
Informationen k�nnen im Blitzforum erfragt werden.
Der Extractor wird in einer Windows und in einer Mac Version ausgeliefert und richtet 
sich in erster Linie an BlitzMax ( http://www.blitzmax.com ) User, denen die 
Bildfonts von BlitzMax zu wenig M�glichkeiten bieten.



Wie er funktioniert:
Nachdem das Programm ausgef�hrt wird, erscheint ein Fenster mit einer Listbox, Buttons zum 
bearbeiten und einem Vorschau-Fenster. Die Buttons haben folgende Bedeutung:

- Suchen:
  Nach einem Klick auf diesen Button erscheint ein weiteres Fenster mit einem Button der die Aufschrift
  "Start" hat. Dr�ckt man den Startbutton, durchsucht das Programm die ganze Festplatte nach Freetype
  Fonts. Diese besitzen die Endung ".ttf".
  Alle Fonts, die gefunden werden, werden in der Listbox aufgef�hrt. Die Suche kann jederzeit 
  mit einem Klick auf den Stopbutton beendet werden.

- Sortieren:
  Die links in der Listbox aufgef�hrten Fonts werden nach dem Suchen oder Laden in beliebiger
  Reihenfolge aufgef�hrt. Mit einem Klick auf den Sortierbutton, sortiert das Programm die Fonts
  alphabetisch.

- Laden:
  Nach einem Klick auf den Ladebutton, �ffnet sich ein Dateidialog und der Benutzer hat die M�glichkeit,
  einen einzelnen Font zu laden.

- Speichern:
  Hat der Benutzer einen Font mit der Maus ausgew�hlt, kann er mit einem Klick auf den Speicherbutton
  gespeichert werden. Zuvor �ffnet sich jedoch noch ein kleines Fenster mit Einstellungsm�glichkeiten.


- Das Vorschaufenster:
  W�hlt man in der Listbox einen Font aus, wird im Vorschaufenster eine kleine Vorschau des Fonts
  gezeichnet. Der dort angezeigte Vorschautext kann in der config.txt Datei nach wunsch angepasst
  werden.


- Das Speicherfenster:
  Bevor der Font nach einem Klick auf den Speicherbutton gespeichert wird, hat der Benutzer die
  M�glichkeit, noch letzte Einstellungen vorzunehmen. 

  - Dateiname Feld:
    Bei einem Klick auf den Ausw�hlen-Button, �ffnet sich ein Dateidialog und der Benutzer kann einen
    beliebigen Pfad und Dateinamen ausw�hlen. Dorthin wird der Font nach einem Klick auf 
    "Speichern" gespeichetr.
 
  - Chars Feld:
    Hier sind die Buchstaben aufgelistet, die nach dem Speichern im Bild zu sehen sein werden. Diese
    Zeichenketten k�nnen beliebig bearbeitet werden und unterhalb in der Combobox "Charset" kann
    man einige von mir vorgegebene Zeichenketten w�hlen.

  - Fontgr��e:
    Die Gr��e der einzelnen Buchstaben, die im Bild gespeichert werden. Vorgegeben ist eine Gr��e von 
    16. Umso h�her die Gr��e ist, umso h�her ist die Qualit�t. Ich empfehle also eine Gr��e von 
    mindestens 40, um eine anst�ndige Qualit�t zu erreichen.

   - Charset:
   Siehe Chars Feld


Das wars. Ich w�nsche euch viel Spass damit und bei Fragen kann man mich jederzeit im Blitzforum oder
per E-Mail erreichen. Die Daten stehen oben.

Mein Dank gilt f�r die Mithilfe an dem Projekt an 
- D-Bug
- Hamzta

Mfg Suco



